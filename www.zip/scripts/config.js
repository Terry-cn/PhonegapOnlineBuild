window.AKHB ={
	config:{
		// https://www.iiuk.org/Pages/App/webservice.php
		// http://stage.iiuk.homeip.net/Pages/App/webservice.php
		remoteAddress : 'http://stage.iiuk.homeip.net/Pages/App/webservice.php',
		debug:true,
		version:null,
		timeout:60*1000*30,
		taskTimeout:1000*30,
		messageSyncTimeout:1000*30,
		senderID:'31742222780'
	}
};