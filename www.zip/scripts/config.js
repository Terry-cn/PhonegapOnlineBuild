window.AKHB ={
	config:{
		// http://www.iiuk.org/Pages/HealthBoard_App/webservice.php
		remoteAddress : 'http://stage.iiuk.homeip.net/Pages/App',
		debug:true,
		version:null,
		timeout:60*1000*30,
		senderID:'675297324332'
	}
};